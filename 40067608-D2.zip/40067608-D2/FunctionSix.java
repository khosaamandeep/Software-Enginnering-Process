
import java.util.Scanner;

public class FunctionSix
{

public static void main(String[] args)
{
Scanner s=new Scanner(System.in);
//Take input x as exponential variable

	System.out.println("Enter X.");
	double x=s.nextDouble();
	
	// Take input b as first variable 

	System.out.println("Enter b.");
	double b=s.nextDouble();
	// Take input a as second variable 

	System.out.println("Enter A.");
	double a=s.nextDouble();
	function6(x,b,a);

}


	static double function6(double x, double b, double a) {
		double resultFinal = 0;
		try
		{	
		while(b<0){
		System.out.println("Cannot be Negative, Re-Enter.");
		return 0;
		}
		resultFinal=a*resultOne(b,x);
		System.out.println("The desired value of a function(a * (b)^x ) is: "+resultFinal);
		
		}
		catch(Exception e)
		{
			System.out.println("Please enter valid number input !!! Try again");
			main(new String[0]);
		}
		return resultFinal;
	
}


	public static double resultOne(double b,double x)
	{
	double check=1;
	for(int i=0;i<x;i++){
		check=check*b;
	}

	return check;
	}

}
		    