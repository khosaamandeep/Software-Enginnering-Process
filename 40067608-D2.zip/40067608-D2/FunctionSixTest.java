import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import junit.framework.Assert;

class FunctionSixTest {

	@Test
	void test() {
		FunctionSix f6=new FunctionSix();
		Assert.assertEquals(36.00, f6.function6(2.0, 3.0, 4.0),Math.abs(36.00));
		Assert.assertEquals(0, f6.function6(3.0, -1, 4.0),Math.abs(0));
		Assert.assertEquals(0, f6.function6(0, 0, 0),Math.abs(0));
	}

}
